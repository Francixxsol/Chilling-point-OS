from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from core import views
urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.dashboard, name="dashboard"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("team/", views.team, name="team"),
    path("shifts/", views.shifts, name="shifts"),
    path("shifts/create/", views.create_shift, name="create_shift"),
    path("shifts/<int:shift_id>/assign/", views.assign_shift, name="assign_shift"),
    path("day/close/", views.close_day, name="close_day"),
    path("attendance/<int:assignment_id>/<str:action>/", views.attendance, name="attendance"),
    path("meal/<int:assignment_id>/", views.toggle_meal, name="toggle_meal"),
    path("sales/", views.sales, name="sales"),
    path("logbook/", views.logbook, name="logbook"),
    path("announcements/", views.announcements, name="announcements"),
    path("ceo/", views.ceo, name="ceo"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
