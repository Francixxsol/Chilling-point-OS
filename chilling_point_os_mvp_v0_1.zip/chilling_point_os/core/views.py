from datetime import date
from decimal import Decimal
from math import radians, sin, cos, sqrt, atan2
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import *
from .forms import *

# Configure the actual restaurant coordinates and radius before enabling geofenced attendance.
SHOP_LAT = None
SHOP_LON = None
SHOP_RADIUS_METRES = 100

def profile(user):
    return getattr(user, "profile", None)
def is_manager(user):
    p = profile(user)
    return user.is_superuser or (p and p.role in ["CEO","MANAGER"])
def is_ceo(user):
    p = profile(user)
    return user.is_superuser or (p and p.role == "CEO")
def login_view(request):
    if request.user.is_authenticated: return redirect("dashboard")
    if request.method == "POST":
        user = authenticate(request, username=request.POST.get("username"), password=request.POST.get("password"))
        if user:
            login(request, user); return redirect("dashboard")
        messages.error(request, "Username or password is incorrect.")
    return render(request, "core/login.html")
def logout_view(request):
    logout(request); return redirect("login")

@login_required
def dashboard(request):
    today = timezone.localdate()
    p = profile(request.user)
    if p and p.role not in ["CEO","MANAGER"]:
        assignments = ShiftAssignment.objects.filter(staff=p, shift__date__gte=today).exclude(status="CANCELLED").select_related("shift").order_by("shift__date")
        notices = Announcement.objects.order_by("-created_at")[:5]
        return render(request, "core/staff_home.html", {"assignments":assignments,"notices":notices,"today":today})
    days = BusinessDay.objects.filter(date__gte=today).order_by("date")[:7]
    assignments = ShiftAssignment.objects.filter(shift__date=today, status="ASSIGNED").select_related("staff__user","shift")
    sales = DailySales.objects.filter(date=today).first()
    labor = sum((a.net_pay for a in assignments), Decimal("0"))
    return render(request, "core/dashboard.html", {"today":today,"days":days,"assignments":assignments,"sales":sales,"labor":labor,"labor_pct":(labor/sales.total_sales*100 if sales and sales.total_sales else 0),"alerts":assignments.filter(clock_in__isnull=True).count()})

@login_required
def ceo(request):
    if not is_ceo(request.user): return HttpResponseForbidden("CEO access only.")
    sales = DailySales.objects.order_by("-date")[:14]
    staff = StaffProfile.objects.filter(active=True).select_related("user")
    return render(request,"core/ceo.html",{"sales":sales,"staff":staff,"closed_days":BusinessDay.objects.filter(status="CLOSED").count()})

@login_required
def team(request):
    if not is_manager(request.user): return HttpResponseForbidden()
    return render(request,"core/team.html",{"staff":StaffProfile.objects.filter(active=True).select_related("user").order_by("role","user__first_name")})

@login_required
def shifts(request):
    if not is_manager(request.user): return HttpResponseForbidden()
    selected = request.GET.get("date")
    qs = Shift.objects.all().order_by("date","start_time")
    if selected: qs = qs.filter(date=selected)
    return render(request,"core/shifts.html",{"shifts":qs,"today":timezone.localdate(),"staff":StaffProfile.objects.filter(active=True)})

@login_required
@require_POST
def create_shift(request):
    if not is_manager(request.user): return HttpResponseForbidden()
    form = ShiftForm(request.POST)
    if form.is_valid():
        shift = form.save()
        messages.success(request,"Shift created. Assign staff from the rota.")
    else: messages.error(request,"Please check the shift details.")
    return redirect("shifts")

@login_required
@require_POST
def assign_shift(request, shift_id):
    if not is_manager(request.user): return HttpResponseForbidden()
    shift = get_object_or_404(Shift, pk=shift_id)
    if BusinessDay.objects.filter(date=shift.date,status="CLOSED").exists():
        messages.error(request,"This business day is closed; assignments are blocked.")
        return redirect("shifts")
    staff = get_object_or_404(StaffProfile,pk=request.POST.get("staff_id"),active=True)
    if staff.role != shift.department:
        messages.error(request,"Choose a staff member from the matching department.")
        return redirect("shifts")
    rate = {"MORNING":staff.pay_morning,"EVENING":staff.pay_evening,"FULL":staff.pay_full}[shift.shift_type]
    if shift.shift_type in ["MORNING","EVENING"]:
        other = "EVENING" if shift.shift_type == "MORNING" else "MORNING"
        if ShiftAssignment.objects.filter(staff=staff,shift__date=shift.date,shift__shift_type=other,status="ASSIGNED").exists():
            messages.warning(request,"This person already has the other shift. Review the full-day rate before assigning.")
    ShiftAssignment.objects.get_or_create(staff=staff,shift=shift,defaults={"assigned_rate":rate})
    messages.success(request,"Staff assignment saved.")
    return redirect("shifts")

@login_required
@require_POST
def close_day(request):
    if not is_manager(request.user): return HttpResponseForbidden()
    day = request.POST.get("date")
    reason = request.POST.get("reason","Operational closure")
    BusinessDay.objects.update_or_create(date=day,defaults={"status":"CLOSED","closure_reason":reason,"closed_by":request.user})
    Shift.objects.filter(date=day).update(is_open=False)
    ShiftAssignment.objects.filter(shift__date=day,status="ASSIGNED").update(status="CANCELLED")
    messages.warning(request,f"{day} marked CLOSED. Assignments cancelled; review staff notifications manually.")
    return redirect("dashboard")

def distance_m(lat1,lon1,lat2,lon2):
    r=6371000
    dlat=radians(float(lat2)-float(lat1)); dlon=radians(float(lon2)-float(lon1))
    a=sin(dlat/2)**2+cos(radians(float(lat1)))*cos(radians(float(lat2)))*sin(dlon/2)**2
    return 2*r*atan2(sqrt(a),sqrt(1-a))

@login_required
@require_POST
def attendance(request, assignment_id, action):
    a=get_object_or_404(ShiftAssignment,pk=assignment_id)
    p=profile(request.user)
    if not (is_manager(request.user) or (p and a.staff_id==p.id)): return HttpResponseForbidden()
    if action=="in":
        if a.clock_in: messages.info(request,"Already clocked in.")
        elif SHOP_LAT is None or SHOP_LON is None:
            messages.error(request,"Geofence is not configured. Set SHOP_LAT and SHOP_LON in core/views.py before enabling clock-in.")
        elif not request.FILES.get("selfie"):
            messages.error(request,"A clock-in selfie is required.")
        else:
            try:
                lat=float(request.POST["latitude"]); lon=float(request.POST["longitude"])
                if distance_m(SHOP_LAT,SHOP_LON,lat,lon)>SHOP_RADIUS_METRES:
                    messages.error(request,"Outside the restaurant attendance radius.")
                else:
                    a.clock_in=timezone.now(); a.latitude=Decimal(str(lat)); a.longitude=Decimal(str(lon)); a.selfie=request.FILES["selfie"]; a.save()
                    messages.success(request,"Clock-in recorded.")
            except (KeyError,ValueError): messages.error(request,"Location permission is required.")
    elif action=="out":
        if not a.clock_in: messages.error(request,"Clock in first.")
        else:
            a.clock_out=timezone.now(); a.status="DONE"; a.save(); messages.success(request,"Clock-out recorded.")
    return redirect("dashboard")

@login_required
@require_POST
def toggle_meal(request, assignment_id):
    if not is_manager(request.user): return HttpResponseForbidden()
    a=get_object_or_404(ShiftAssignment,pk=assignment_id)
    try: count=int(request.POST.get("count","0"))
    except ValueError: count=0
    a.meal_count=max(0,min(2,count)); a.save()
    messages.success(request,"Meal count updated; estimated net pay recalculated.")
    return redirect("shifts")

@login_required
def sales(request):
    if not is_manager(request.user): return HttpResponseForbidden()
    if request.method=="POST":
        form=SalesForm(request.POST)
        if form.is_valid():
            obj,created=DailySales.objects.update_or_create(date=form.cleaned_data["date"],defaults={**form.cleaned_data,"entered_by":request.user})
            messages.success(request,"Sales record saved.")
            return redirect("sales")
    else: form=SalesForm()
    return render(request,"core/sales.html",{"form":form,"records":DailySales.objects.order_by("-date")[:20]})

@login_required
def logbook(request):
    if request.method=="POST" and is_manager(request.user):
        form=LogForm(request.POST)
        if form.is_valid():
            obj=form.save(commit=False); obj.created_by=request.user; obj.save(); messages.success(request,"Handover note saved."); return redirect("logbook")
    else: form=LogForm()
    return render(request,"core/logbook.html",{"form":form,"entries":LogEntry.objects.order_by("-created_at")[:40]})

@login_required
def announcements(request):
    if request.method=="POST" and is_manager(request.user):
        form=AnnouncementForm(request.POST)
        if form.is_valid():
            obj=form.save(commit=False); obj.created_by=request.user; obj.save(); messages.success(request,"Announcement posted."); return redirect("announcements")
    else: form=AnnouncementForm()
    return render(request,"core/announcements.html",{"form":form,"items":Announcement.objects.order_by("-created_at")[:30]})
