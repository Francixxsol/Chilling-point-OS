from django.contrib import admin
from .models import *
admin.site.register(StaffProfile)
admin.site.register(BusinessDay)
admin.site.register(Shift)
admin.site.register(ShiftAssignment)
admin.site.register(ShiftPoolRequest)
admin.site.register(DailySales)
admin.site.register(LogEntry)
admin.site.register(Announcement)
