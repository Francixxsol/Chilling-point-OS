from django import forms
from .models import Shift, DailySales, LogEntry, Announcement
class ShiftForm(forms.ModelForm):
    class Meta:
        model = Shift
        fields = ["date","shift_type","start_time","end_time","department","required_count","bonus"]
        widgets = {"date": forms.DateInput(attrs={"type":"date"}), "start_time": forms.TimeInput(attrs={"type":"time"}), "end_time": forms.TimeInput(attrs={"type":"time"})}
class SalesForm(forms.ModelForm):
    class Meta:
        model = DailySales
        fields = ["date","total_sales","cash_remitted","transfer_sales","expenses"]
        widgets = {"date": forms.DateInput(attrs={"type":"date"})}
class LogForm(forms.ModelForm):
    class Meta:
        model = LogEntry
        fields = ["shift_label","category","message"]
class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ["message"]
