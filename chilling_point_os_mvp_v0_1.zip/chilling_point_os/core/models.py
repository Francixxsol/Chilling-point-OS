from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from decimal import Decimal

class StaffProfile(models.Model):
    ROLE_CHOICES = [("CEO","CEO"),("MANAGER","Manager"),("KITCHEN","Kitchen"),("WAITER","Waiter"),("BAR","Bar"),("RIDER","Rider")]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    phone = models.CharField(max_length=20, blank=True)
    role = models.CharField(max_length=12, choices=ROLE_CHOICES, default="WAITER")
    pay_morning = models.DecimalField(max_digits=10, decimal_places=2, default=1000)
    pay_evening = models.DecimalField(max_digits=10, decimal_places=2, default=700)
    pay_full = models.DecimalField(max_digits=10, decimal_places=2, default=1400)
    active = models.BooleanField(default=True)
    availability_note = models.CharField(max_length=180, blank=True)
    def __str__(self): return f"{self.user.get_full_name() or self.user.username} · {self.role}"

class BusinessDay(models.Model):
    date = models.DateField(unique=True)
    STATUS = [("OPEN","Open"),("CLOSED","Closed")]
    status = models.CharField(max_length=8, choices=STATUS, default="OPEN")
    closure_reason = models.CharField(max_length=180, blank=True)
    closed_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    def __str__(self): return f"{self.date} · {self.status}"

class Shift(models.Model):
    TYPES = [("MORNING","Morning"),("EVENING","Evening"),("FULL","Full day")]
    date = models.DateField()
    shift_type = models.CharField(max_length=10, choices=TYPES)
    start_time = models.TimeField()
    end_time = models.TimeField()
    department = models.CharField(max_length=20, choices=[("KITCHEN","Kitchen"),("WAITER","Waiter"),("BAR","Bar"),("RIDER","Rider")])
    required_count = models.PositiveSmallIntegerField(default=1)
    bonus = models.DecimalField(max_digits=9, decimal_places=2, default=0)
    is_open = models.BooleanField(default=True)
    def __str__(self): return f"{self.date} {self.get_shift_type_display()} · {self.get_department_display()}"

class ShiftAssignment(models.Model):
    STATUS = [("ASSIGNED","Assigned"),("POOL","In pool"),("CANCELLED","Cancelled"),("DONE","Completed")]
    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE, related_name="assignments")
    shift = models.ForeignKey(Shift, on_delete=models.CASCADE, related_name="assignments")
    assigned_rate = models.DecimalField(max_digits=9, decimal_places=2)
    status = models.CharField(max_length=12, choices=STATUS, default="ASSIGNED")
    clock_in = models.DateTimeField(null=True, blank=True)
    clock_out = models.DateTimeField(null=True, blank=True)
    selfie = models.ImageField(upload_to="attendance/", null=True, blank=True)
    latitude = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    longitude = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    meal_count = models.PositiveSmallIntegerField(default=0)
    meal_unit_cost = models.DecimalField(max_digits=8, decimal_places=2, default=1000)
    manager_note = models.CharField(max_length=180, blank=True)
    @property
    def meal_deduction(self): return self.meal_count * self.meal_unit_cost
    @property
    def net_pay(self): return max(Decimal("0"), self.assigned_rate - self.meal_deduction) + self.shift.bonus
    class Meta:
        constraints = [models.UniqueConstraint(fields=["staff","shift"], name="unique_staff_shift")]

class ShiftPoolRequest(models.Model):
    assignment = models.OneToOneField(ShiftAssignment, on_delete=models.CASCADE)
    reason = models.CharField(max_length=180)
    picked_by = models.ForeignKey(StaffProfile, null=True, blank=True, on_delete=models.SET_NULL, related_name="picked_shifts")
    approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

class DailySales(models.Model):
    date = models.DateField(unique=True)
    total_sales = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    cash_remitted = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    transfer_sales = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    expenses = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    entered_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    @property
    def labor_cost(self):
        return sum((a.net_pay for a in ShiftAssignment.objects.filter(shift__date=self.date, status__in=["ASSIGNED","DONE"])), Decimal("0"))
    @property
    def labor_percent(self):
        return (self.labor_cost / self.total_sales * 100) if self.total_sales else Decimal("0")
    @property
    def cash_gap(self): return max(Decimal("0"), self.total_sales - self.cash_remitted - self.transfer_sales)

class LogEntry(models.Model):
    CATEGORY = [("HANDOVER","Handover"),("STOCK","Stock"),("EQUIPMENT","Equipment"),("CUSTOMER","Customer"),("STAFF","Staff"),("OTHER","Other")]
    created_at = models.DateTimeField(default=timezone.now)
    shift_label = models.CharField(max_length=20, blank=True)
    category = models.CharField(max_length=12, choices=CATEGORY, default="HANDOVER")
    message = models.TextField()
    resolved = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)

class Announcement(models.Model):
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
