# Chilling Point OS — MVP 0.1

A lightweight Django starter for a Nigerian eatery operations system. Includes CEO-only access, manager workspace, staff workspace, rota, pay estimates, meal deductions, attendance foundation, sales ledger, labor percentage, closure controls, announcements and handover logbook.

## Run locally

1. Install Python 3.10+.
2. In this folder, create a virtual environment and install dependencies:

   `python -m venv .venv`

   Windows: `.venv\\Scripts\\activate`

   `pip install -r requirements.txt`

3. Create database tables:

   `python manage.py makemigrations core`

   `python manage.py migrate`

4. Create the first admin login:

   `python manage.py createsuperuser`

5. Start:

   `python manage.py runserver`

6. Open `http://127.0.0.1:8000/`

## First setup

- Sign in using the superuser.
- Open `/admin/`.
- Create staff login accounts under **Users**.
- Create one **Staff profile** per user and assign the role: CEO, MANAGER, KITCHEN, WAITER, BAR or RIDER.
- Configure each person's morning, evening and full-day rates.
- Create shifts from the Rota screen and assign matching department staff.
- Enter daily sales and handovers.

A Django superuser has CEO access. A normal account must have a StaffProfile with role CEO to access `/ceo/`.

## Important: before real staff attendance

The attendance view deliberately refuses clock-ins until the real restaurant latitude and longitude are configured in `core/views.py` (`SHOP_LAT`, `SHOP_LON`). Set a radius suitable for the premises. Run the site over HTTPS in production; browser geolocation generally requires HTTPS. The selfie is uploaded as evidence, not automatically facially verified.

## MVP scope and honest limitations

Working foundation:
- Role-aware dashboard routing and CEO-only URL protection
- Staff directory (accounts/profiles managed in Django Admin)
- Shift creation and department assignment
- Morning/evening/full-day pay rates
- Meal count and estimated net-pay calculation
- Business-day closure and assignment cancellation
- Geofence + selfie attendance foundation
- Daily sales, labor-cost percentage and cash-gap signal
- Manager logbook and announcements

Not yet integrated:
- WhatsApp Business Cloud API / automated notifications
- OPay disbursements or wallet custody
- AI auto-scheduler and weather/NEPA feeds
- Offline-first sync / PWA installation
- Voice transcription, CCTV, POS integrations and QR/selfie identity verification
- Shift-pool approval interface, audit-grade theft investigation and automated payroll settlement

Do not treat the cash-gap signal as proof of theft. Reconcile POS settlements, transfers, refunds and expenses first.

## Production checklist

- Replace `SECRET_KEY`; set `DEBUG=False`; configure `ALLOWED_HOSTS`.
- Use PostgreSQL, HTTPS, secure cookies, backups and object storage for uploaded selfies.
- Add audit logs for pay changes, shift edits, approvals and closures.
- Add consent, retention and access rules for staff location and selfie data.
- Confirm wage, meal deduction, overtime and payroll policies with staff before using automated deductions.
- Add a proper approval and payout integration before advertising instant wallet payments.
